package bmiCalculator;

public class MainProgram {

	public static void main(String[] args) {

		AppWindow bmi = new AppWindow();

	}

}
