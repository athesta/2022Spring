module Assignment_1 {
	requires java.desktop;
}